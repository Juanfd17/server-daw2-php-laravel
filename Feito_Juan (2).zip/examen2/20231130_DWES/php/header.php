<nav>
    <ul>
        <li><a href="./index.php">Pagina inicial</a></li>
        <li><a href="miscompras.php">Mis Compras</a></li>
        <li><a href="./nuevaCompra.php">Nueva compra</a></li>
        <li><a href="./desconectar.php">Desconectar</a></li>
    </ul>
</nav>