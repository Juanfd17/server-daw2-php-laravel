<?php

class Cliente
{

}