<?php

interface Precipitable {
    function medidaPrecictacionAnual();
}